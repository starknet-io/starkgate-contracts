from solidity.utils import load_contract

MockStarknetMessaging = load_contract("MockStarknetMessaging")
